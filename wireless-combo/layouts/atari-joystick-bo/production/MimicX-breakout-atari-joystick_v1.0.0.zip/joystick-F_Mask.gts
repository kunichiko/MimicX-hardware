G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*
G04 #@! TF.CreationDate,2026-10-20T23:55:47+09:00*
G04 #@! TF.ProjectId,joystick,6a6f7973-7469-4636-9b2e-6b696361645f,v1.0.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2026-10-20 23:55:47*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,4.000000X1.500000*%
%ADD11RoundRect,0.250000X-0.600000X-0.600000X0.600000X-0.600000X0.600000X0.600000X-0.600000X0.600000X0*%
%ADD12C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X127700000Y-94460000D03*
X127700000Y-97230000D03*
X127700000Y-100000000D03*
X127700000Y-102770000D03*
X127700000Y-105540000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X98247500Y-94920000D03*
D12*
X100787500Y-94920000D03*
X98247500Y-97460000D03*
X100787500Y-97460000D03*
X98247500Y-100000000D03*
X100787500Y-100000000D03*
X98247500Y-102540000D03*
X100787500Y-102540000D03*
X98247500Y-105080000D03*
X100787500Y-105080000D03*
G04 #@! TD*
M02*
