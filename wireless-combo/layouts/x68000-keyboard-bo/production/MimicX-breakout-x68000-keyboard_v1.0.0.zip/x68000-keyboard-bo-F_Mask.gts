G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*
G04 #@! TF.CreationDate,2026-11-23T15:37:37+09:00*
G04 #@! TF.ProjectId,x68000-keyboard-bo,78363830-3030-42d6-9b65-79626f617264,v1.0.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2026-11-23 15:37:37*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.400000*%
%ADD11R,4.000000X1.200000*%
%ADD12RoundRect,0.250000X-0.600000X-0.600000X0.600000X-0.600000X0.600000X0.600000X-0.600000X0.600000X0*%
%ADD13C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X174920000Y-97117600D03*
X174920000Y-94577600D03*
D11*
X178000000Y-98300000D03*
X178000000Y-96000000D03*
X178000000Y-93700000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J1*
X150247500Y-92190000D03*
D13*
X152787500Y-92190000D03*
X150247500Y-94730000D03*
X152787500Y-94730000D03*
X150247500Y-97270000D03*
X152787500Y-97270000D03*
X150247500Y-99810000D03*
X152787500Y-99810000D03*
G04 #@! TD*
M02*
